# BÁO CÁO THỰC HÀNH LAB 05: TÌM KIẾM ĐỐI KHÁNG VÀ TRÒ CHƠI
**Môn học:** Trí tuệ nhân tạo nâng cao (Advanced Artificial Intelligence)  
**Giảng viên hướng dẫn:** Thầy Đỗ Như Tài  
**Sinh viên thực hiện:** Trần Lê Minh Tâm 
**Mã số sinh viên:** 3124720064  
**Lớp chuyên ngành:** DNT1241  

---

## 1. Cấu trúc thư mục nộp bài
* **Báo cáo chính:**
  * `báo cáo lab05.docx` (hoặc `baocao_lab05.docx`): Báo cáo chi tiết dạng Word (9 trang chuẩn mực, đầy đủ bảng biểu, phân tích chuyên sâu và trả lời 6 câu hỏi thảo luận).
  * `báo cáo lab05.pdf` (hoặc `baocao_lab05.pdf`): Bản xuất PDF chính thức 9 trang hoàn chỉnh, chuẩn bìa và định dạng, sẵn sàng nộp bài.
* **Mã nguồn thực hành Tic-Tac-Toe (Bài 1 – Bài 7):**
  * `tictactoe.py`: Thư viện định nghĩa môi trường, kiểm tra kết thúc và hiển thị bàn cờ.
  * `tictactoe_definitions.ipynb`: Bài 1 - Định nghĩa trò chơi và thử nghiệm 1.000 ván Random vs Random.
  * `tictactoe_and_or_tree_search.ipynb`: Bài 2 - Giải Tic-Tac-Toe bằng AND-OR Tree Search (kế hoạch điều kiện).
  * `tictactoe_alpha_beta_tree_search.ipynb`: Bài 3 - So sánh Minimax và Alpha-Beta Pruning, tối ưu Move Ordering.
  * `tictactoe_heuristic_alpha_beta_tree_search.ipynb`: Bài 4 - Heuristic Alpha-Beta với giới hạn độ sâu (cutoff=2, 4).
  * `tictactoe_pure_monte_carlo_search.ipynb`: Bài 5 - Pure Monte Carlo Search (PMCS) với N = 10, 100, 1000.
  * `tictactoe_monte_carlo_tree_search_restricted.ipynb`: Bài 6 - MCTS độ sâu 1 với chính sách chọn UCB1.
  * `tictactoe_interactive.ipynb`: Bài 7 - Giao diện chơi tương tác trực tiếp người đấu với tác tử.
* **Bài tập mở rộng (Bài 8 – Bài 10):**
  * `assignment_connect4.ipynb`: **Hoàn thành 100%** bài tập Connect 4 từ Task 1 đến Task 5 + Graduate task (Best first move, Move ordering, Heuristic 4-window, Cutoff search, PMCS).
  * `assignment_mean_connect4.ipynb`: **Hoàn thành 100%** bài tập Mean Connect 4 (Quy tắc di chuyển quân đối thủ ở hàng đáy, phân tích không gian trạng thái, Move ordering, Heuristic cutoff, PMCS và Best first move).
  * `assignment_dots_and_boxes.ipynb`: **Hoàn thành 100%** bài tập Dots and Boxes (Mô hình hóa cạnh và hộp, quy tắc thêm lượt khi chiếm hộp, Minimax + Alpha-Beta, Move ordering ưu tiên chiếm hộp & tránh nhả cạnh thứ 3, Heuristic cutoff, PMCS và phân tích nước đi biên tối ưu).
* **Phân tích bổ trợ:**
  * `profiling_code.ipynb`: Đo lường và tối ưu hóa thời gian thực thi mã nguồn.
  * `store_agent_state_information.ipynb`: Lưu trữ trạng thái và bảng tra cứu (transposition table).

---

## 2. Hướng dẫn chạy và tái hiện kết quả
1. Yêu cầu môi trường: Python 3.10+ với các thư viện: `numpy`, `matplotlib`.
2. Khởi chạy Jupyter Notebook hoặc Jupyter Lab:
   ```bash
   jupyter notebook
   ```
3. Mở các file `.ipynb` tương ứng và chọn `Kernel` -> `Restart & Run All`. Toàn bộ kết quả đầu ra đã được chạy sẵn và lưu trong các cell.
